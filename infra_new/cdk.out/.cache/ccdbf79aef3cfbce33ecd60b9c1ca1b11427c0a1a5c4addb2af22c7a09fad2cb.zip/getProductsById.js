"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getProductsById = void 0;

const products = [
  { id: '1', title: 'Classic White T-Shirt', price: 14.99, description: '100% cotton, unisex, available in all sizes' },
  { id: '2', title: 'Blue Denim Jeans', price: 39.99, description: 'Slim fit, stretchable, various waist sizes' },
  { id: '3', title: 'Red Hoodie', price: 29.99, description: 'Soft fleece, kangaroo pocket, drawstring hood' },
  { id: '4', title: 'Black Leather Jacket', price: 89.99, description: 'Genuine leather, biker style, limited edition' },
  { id: '5', title: 'Green Chino Shorts', price: 24.99, description: 'Lightweight, breathable, perfect for summer' },
];

const getProductsById = async (event) => {
  console.log('Lambda invoked', JSON.stringify(event));
  
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const productId = event.pathParameters?.productId;
    
    if (!productId) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ message: 'Product ID is required' }),
      };
    }

    const product = products.find(p => p.id === productId);
    
    if (!product) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ message: 'Product not found' }),
      };
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(product),
    };
  } catch (error) {
    console.error('Error fetching product:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ message: 'Internal Server Error' }),
    };
  }
};
exports.getProductsById = getProductsById;
